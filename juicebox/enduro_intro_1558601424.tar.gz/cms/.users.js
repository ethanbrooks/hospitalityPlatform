({
	users: [
		{
			username: 'ebr00ks',
			tags: [],
			salt: 'fe952445049453e1d76c151f651187cc',
			hash: '86acbc0a5ccb78124f6ff0ba1f34b4abca5ffd5675886584273e2ea0b18cd082',
			user_created_timestamp: 1558480824876
		}
	]
})